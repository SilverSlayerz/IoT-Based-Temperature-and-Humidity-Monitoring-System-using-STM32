#include "lcd.h"
#include "stm32f4xx_hal.h"

static void Lcd_enable(Lcd_HandleTypeDef *lcd)
{
    HAL_GPIO_WritePin(lcd->en_port, lcd->en_pin, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(lcd->en_port, lcd->en_pin, GPIO_PIN_RESET);
    HAL_Delay(1);
}

// CORRECTED THIS FUNCTION
static void Lcd_write_4bits(Lcd_HandleTypeDef *lcd, char data)
{
    for (int i = 0; i < 4; i++)
    {
        HAL_GPIO_WritePin(lcd->data_ports[i], lcd->data_pins[i],
                         (data & (1 << i)) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }
    Lcd_enable(lcd);
}

void Lcd_send_cmd(Lcd_HandleTypeDef *lcd, char cmd)
{
    HAL_GPIO_WritePin(lcd->rs_port, lcd->rs_pin, GPIO_PIN_RESET);
    Lcd_write_4bits(lcd, (cmd >> 4) & 0x0F);
    Lcd_write_4bits(lcd, cmd & 0x0F);
    HAL_Delay(2);
}

void Lcd_send_data(Lcd_HandleTypeDef *lcd, char data)
{
    HAL_GPIO_WritePin(lcd->rs_port, lcd->rs_pin, GPIO_PIN_SET);
    Lcd_write_4bits(lcd, (data >> 4) & 0x0F);
    Lcd_write_4bits(lcd, data & 0x0F);
    HAL_Delay(1);
}

void Lcd_init(Lcd_HandleTypeDef *lcd)
{
    HAL_Delay(20);
    Lcd_send_cmd(lcd, 0x02); // 4-bit mode
    Lcd_send_cmd(lcd, 0x28); // 2 lines, 5x8 font
    Lcd_send_cmd(lcd, 0x0C); // display on, cursor off
    Lcd_send_cmd(lcd, 0x06); // auto increment cursor
    Lcd_send_cmd(lcd, 0x01); // clear display
    HAL_Delay(3);
}

void Lcd_clear(Lcd_HandleTypeDef *lcd)
{
    Lcd_send_cmd(lcd, 0x01); // Command to clear display
    HAL_Delay(2);          // This command takes longer
}

void Lcd_puts(Lcd_HandleTypeDef *lcd, char *str)
{
    while (*str)
        Lcd_send_data(lcd, *str++);
}

void Lcd_gotoxy(Lcd_HandleTypeDef *lcd, int col, int row)
{
    uint8_t address;
    switch (row)
    {
        case 0: address = 0x80 + col; break;
        case 1: address = 0xC0 + col; break;
        default: return;
    }
    Lcd_send_cmd(lcd, address);
}
