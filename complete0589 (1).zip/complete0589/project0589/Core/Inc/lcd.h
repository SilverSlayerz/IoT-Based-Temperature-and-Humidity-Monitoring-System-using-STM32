#ifndef LCD_H
#define LCD_H

#include "stm32f4xx_hal.h"

typedef GPIO_TypeDef* Lcd_PortType;
typedef uint16_t      Lcd_PinType;

typedef enum {
    LCD_4_BIT_MODE = 0
} Lcd_Mode;

typedef struct {
    Lcd_PortType data_ports[4];
    Lcd_PinType  data_pins[4];

    Lcd_PortType rs_port;
    Lcd_PinType  rs_pin;

    Lcd_PortType en_port;
    Lcd_PinType  en_pin;

    Lcd_Mode mode;
} Lcd_HandleTypeDef;

// Function Prototypes
void Lcd_init(Lcd_HandleTypeDef *lcd);
void Lcd_send_cmd(Lcd_HandleTypeDef *lcd, char cmd);
void Lcd_send_data(Lcd_HandleTypeDef *lcd, char data);
void Lcd_puts(Lcd_HandleTypeDef *lcd, char *str);
void Lcd_gotoxy(Lcd_HandleTypeDef *lcd, int col, int row);
void Lcd_clear(Lcd_HandleTypeDef *lcd); // Added for convenience

#endif
